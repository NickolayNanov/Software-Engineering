﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomLinkedList
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            DynamicList<int> list = new DynamicList<int>();
        }
    }
}
