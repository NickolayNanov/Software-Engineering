﻿namespace DataBaseExtended.Contracts
{
    public interface IPerson
    {
        long Id { get; }
        string Name { get; }
    }
}
