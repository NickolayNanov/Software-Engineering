﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solid_Logger.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
