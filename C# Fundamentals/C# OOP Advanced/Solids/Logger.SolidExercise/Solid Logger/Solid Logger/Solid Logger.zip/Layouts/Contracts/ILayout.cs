﻿namespace Solid_Logger.Layouts.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}
