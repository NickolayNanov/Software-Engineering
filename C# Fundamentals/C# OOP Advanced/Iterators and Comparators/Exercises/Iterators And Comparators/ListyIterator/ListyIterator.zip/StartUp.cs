﻿using System;
using System.Linq;

namespace ListyIterator
{
    class StartUp
    {
        private static ListyIterator<string> list;

        static void Main(string[] args)
        {

            string line = Console.ReadLine();

            while (line != "END")
            {
                string[] tokens = line.Split();

                string command = tokens[0];

                switch (command)
                {
                    case "Create":
                        string[] elements = tokens.Skip(1).ToArray();
                        list = new ListyIterator<string>(elements);
                        break;
                    case "Move":
                        Console.WriteLine(list.Move());
                        break;
                    case "HasNext":
                        Console.WriteLine(list.HasNext());
                        break;
                    case "Print":

                        try
                        {
                            list.Print();
                        }
                        catch (InvalidOperationException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }

                        break;
                    case "PrintAll":
                        list.PrintAll();
                        break;
                }

                line = Console.ReadLine();
            }
        }
    }
}
