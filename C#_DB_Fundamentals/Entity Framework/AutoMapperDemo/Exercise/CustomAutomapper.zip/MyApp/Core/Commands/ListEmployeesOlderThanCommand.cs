﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp.Core.Commands
{
    class ListEmployeesOlderThanCommand
    {
    }
}
