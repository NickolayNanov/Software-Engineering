public enum CardType
{
    Debit,
    Credit
}