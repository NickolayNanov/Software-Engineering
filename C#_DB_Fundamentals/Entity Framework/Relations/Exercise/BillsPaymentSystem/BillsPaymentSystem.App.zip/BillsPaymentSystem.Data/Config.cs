﻿namespace BillsPaymentSystem.Data
{
    internal static class Config
    {
        internal static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=BillsPaymentSystem;Integrated Security=True;";
    }
}
