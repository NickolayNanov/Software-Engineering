﻿namespace BillsPaymentSystem.App
{
    using System;
    using BillsPaymentSystem.App.Core;
    using BillsPaymentSystem.App.Core.Contracts;
    using BillsPaymentSystem.Data;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            InitializeSeedData();

            ICommandInterpreter commandInterpreter = new CommandInterpreter();
            IEngine engine = new Engine(commandInterpreter);
            engine.Run();
        }

        private static void InitializeSeedData()
        {
            DbInitializer dbInitializer = new DbInitializer();

            using (BillsPaymentSystemContext context = new BillsPaymentSystemContext())
            {
                dbInitializer.Seed(context);
            }
        }
    }
}
