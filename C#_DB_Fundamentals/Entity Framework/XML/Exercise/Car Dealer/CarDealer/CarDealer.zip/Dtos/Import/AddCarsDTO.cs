﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer.Dtos.Import
{
    public class AddCarsDTO
    {
        public AddCarsDTO()
        {
            this.Parts = new HashSet<PartDto>();
        }

        [XmlElement("make")]
        public string Make { get; set; }

        [XmlElement("model")]
        public string Model { get; set; }

        [XmlElement("TraveledDistance")]
        public long TraveledDistance { get; set; }

        [XmlElement("parts")]
        public HashSet<PartDto> Parts { get; set; }
    }

    public class PartDto
    {
        [XmlElement("partId")]
        public int PartId { get; set; }
    }
}
