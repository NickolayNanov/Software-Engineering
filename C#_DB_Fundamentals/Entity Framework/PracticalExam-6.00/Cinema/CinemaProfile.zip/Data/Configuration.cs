﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Cinema;Trusted_Connection=True";
    }
}
